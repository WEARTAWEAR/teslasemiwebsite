<?php
define('ARTICLES_FILE', 'data/articles.json');
define('TICKER_FILE', 'data/ticker.json');
define('NAV_FILE', 'data/nav.json');
function loadArticles() {
    if (!file_exists(ARTICLES_FILE)) return [];
    return json_decode(file_get_contents(ARTICLES_FILE), true) ?? [];
}
function loadTicker() {
    if (!file_exists(TICKER_FILE)) return ['items'=>['Tesla Semi begins high-volume production in 2026','First public Megacharger opens in Los Angeles — 750 kW charging','Semi Long Range: 500 miles at 82,000 lbs GCW']];
    return json_decode(file_get_contents(TICKER_FILE), true) ?? ['items'=>[]];
}
function loadNav() {
    if (!file_exists(NAV_FILE)) return ['links'=>[['label'=>'News','url'=>'index.php'],['label'=>'Charging','url'=>'#'],['label'=>'Production','url'=>'#'],['label'=>'Video','url'=>'video.php'],['label'=>'Specs','url'=>'#']]];
    return json_decode(file_get_contents(NAV_FILE), true) ?? ['links'=>[]];
}
$all = loadArticles();
$articles = array_values(array_filter($all, fn($a) => $a['published'] ?? false));
$featured = $articles[0] ?? null;
$grid = array_slice($articles, 1, 4);
$more = array_slice($articles, 5, 6);
$ticker = loadTicker();
$nav = loadNav();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>TeslaSemi.com — The Source for Tesla Semi News</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,700;1,400&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet">
  <style>
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
    :root{--bg:#e8e8e4;--card-bg:#f2f2ef;--black:#0a0a0a;--dark:#1a1a1a;--mid:#555;--light:#999;--accent:#c8102e;--border:1.5px solid #0a0a0a;--radius:0px;}
    body{background:var(--bg);color:var(--dark);font-family:'DM Sans',sans-serif;font-size:15px;line-height:1.6;min-height:100vh;}
    a{text-decoration:none;color:inherit;}
    nav{background:var(--black);color:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 40px;height:56px;border-bottom:2px solid var(--accent);position:sticky;top:0;z-index:100;}
    .nav-logo{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:2px;color:#fff;}
    .nav-logo span{color:var(--accent);}
    .nav-links{display:flex;gap:28px;list-style:none;}
    .nav-links a{color:#ccc;font-size:12px;font-weight:500;letter-spacing:1.5px;text-transform:uppercase;transition:color .2s;}
    .nav-links a:hover{color:#fff;}
    .nav-cta{background:var(--accent);color:#fff!important;padding:6px 16px;font-weight:700!important;}
    .ticker-wrap{background:var(--accent);overflow:hidden;height:34px;display:flex;align-items:center;border-bottom:var(--border);}
    .ticker-track{display:flex;animation:ticker 35s linear infinite;white-space:nowrap;padding-left:24px;}
    .ticker-track span{font-size:11px;font-weight:600;color:#fff;padding:0 40px;letter-spacing:.5px;}
    .ticker-track span::before{content:"●";margin-right:12px;font-size:8px;}
    @keyframes ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
    .hero{background:var(--black);color:#fff;padding:60px 40px 50px;border-bottom:var(--border);display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:center;}
    .hero-tag{font-size:11px;font-weight:700;letter-spacing:3px;text-transform:uppercase;color:var(--accent);margin-bottom:14px;}
    .hero-title{font-family:'DM Serif Display',serif;font-size:clamp(36px,5vw,58px);line-height:1.1;margin-bottom:18px;color:#fff;}
    .hero-excerpt{color:#aaa;font-size:15px;line-height:1.7;max-width:480px;margin-bottom:24px;}
    .hero-meta span{color:#aaa;margin-right:16px;font-size:12px;}
    .hero-img-wrap{overflow:hidden;aspect-ratio:16/10;background:#111;}
    .hero-img-wrap img{width:100%;height:100%;object-fit:cover;opacity:.85;transition:opacity .3s;}
    .hero-img-wrap:hover img{opacity:1;}
    .hero-img-placeholder{width:100%;aspect-ratio:16/10;background:#111;}
    .btn{display:inline-block;padding:10px 24px;font-size:12px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;border:1.5px solid #fff;color:#fff;transition:background .2s,color .2s;margin-top:16px;}
    .btn:hover{background:#fff;color:var(--black);}
    .stats-bar{background:var(--black);color:#fff;display:grid;grid-template-columns:repeat(4,1fr);border:var(--border);border-color:var(--black);margin-bottom:48px;}
    .stat-item{padding:24px 28px;border-right:1px solid #333;}
    .stat-item:last-child{border-right:none;}
    .stat-num{font-family:'Bebas Neue',sans-serif;font-size:42px;letter-spacing:1px;color:var(--accent);line-height:1;}
    .stat-label{font-size:11px;color:#888;letter-spacing:1px;text-transform:uppercase;margin-top:4px;}
    .site-wrap{max-width:1300px;margin:0 auto;padding:0 24px;}
    .section-header{display:flex;align-items:baseline;justify-content:space-between;padding:36px 0 16px;border-bottom:var(--border);margin-bottom:24px;}
    .section-title{font-family:'Bebas Neue',sans-serif;font-size:32px;letter-spacing:2px;color:var(--black);}
    .section-link{font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--black);border-bottom:1.5px solid var(--black);padding-bottom:2px;transition:color .2s,border-color .2s;}
    .section-link:hover{color:var(--accent);border-color:var(--accent);}
    .blog-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-bottom:48px;}
    .card{background:var(--card-bg);border:var(--border);display:flex;flex-direction:column;transition:transform .2s,box-shadow .2s;text-decoration:none;color:inherit;}
    .card:hover{transform:translateY(-3px);box-shadow:4px 4px 0 var(--black);}
    .card-header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-bottom:var(--border);background:var(--black);}
    .card-dots{display:flex;gap:5px;}
    .card-dots span{width:8px;height:8px;border-radius:50%;border:1.5px solid #555;display:block;}
    .card-num{font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--accent);}
    .card-img{width:100%;aspect-ratio:16/10;object-fit:cover;border-bottom:var(--border);display:block;}
    .card-img-placeholder{width:100%;aspect-ratio:16/10;background:var(--black);border-bottom:var(--border);}
    .card-body{padding:14px 16px 18px;flex:1;display:flex;flex-direction:column;gap:6px;}
    .card-meta{display:flex;align-items:center;justify-content:space-between;font-size:11px;color:var(--light);font-weight:500;}
    .card-category{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--accent);}
    .card-title{font-family:'DM Serif Display',serif;font-size:18px;line-height:1.25;color:var(--black);margin-top:4px;}
    .card-excerpt{font-size:13px;color:var(--mid);line-height:1.6;margin-top:4px;}
    .card-author{font-size:11px;color:var(--light);margin-top:auto;padding-top:10px;border-top:1px solid #ddd;}
    .card-author strong{color:var(--dark);}
    .card-wide{grid-column:span 2;flex-direction:row;}
    .card-wide .card-img,.card-wide .card-img-placeholder{width:45%;flex-shrink:0;aspect-ratio:auto;border-bottom:none;border-right:var(--border);}
    .card-wide .card-content{flex:1;display:flex;flex-direction:column;}
    .card-wide .card-title{font-size:24px;}
    .newsletter{background:var(--black);border:var(--border);padding:40px;display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:center;margin-bottom:48px;}
    .newsletter-title{font-family:'Bebas Neue',sans-serif;font-size:36px;color:#fff;letter-spacing:2px;line-height:1.1;}
    .newsletter-title span{color:var(--accent);}
    .newsletter-sub{color:#888;font-size:13px;margin-top:8px;}
    .newsletter-form{display:flex;}
    .newsletter-form input{flex:1;padding:12px 16px;background:#1a1a1a;border:1.5px solid #333;border-right:none;color:#fff;font-family:'DM Sans',sans-serif;font-size:14px;outline:none;}
    .newsletter-form input:focus{border-color:var(--accent);}
    .newsletter-form button{padding:12px 24px;background:var(--accent);color:#fff;border:1.5px solid var(--accent);font-family:'DM Sans',sans-serif;font-size:12px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;cursor:pointer;}
    .newsletter-form button:hover{background:#a00d26;}
    .empty-state{text-align:center;padding:80px 40px;color:var(--mid);}
    .empty-state h2{font-family:'Bebas Neue',sans-serif;font-size:32px;margin-bottom:12px;color:var(--black);}
    footer{background:var(--black);color:#fff;border-top:2px solid var(--accent);padding:40px;}
    .footer-inner{max-width:1300px;margin:0 auto;display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:40px;padding-bottom:32px;border-bottom:1px solid #222;}
    .footer-brand-name{font-family:'Bebas Neue',sans-serif;font-size:28px;letter-spacing:2px;margin-bottom:10px;}
    .footer-brand-name span{color:var(--accent);}
    .footer-brand-desc{color:#666;font-size:13px;line-height:1.7;max-width:280px;}
    .footer-col h4{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#888;margin-bottom:14px;}
    .footer-col ul{list-style:none;}
    .footer-col ul li{margin-bottom:8px;}
    .footer-col ul li a{color:#aaa;font-size:13px;transition:color .2s;}
    .footer-col ul li a:hover{color:#fff;}
    .footer-bottom{max-width:1300px;margin:0 auto;padding-top:20px;display:flex;justify-content:space-between;font-size:12px;color:#555;}
    .footer-bottom a{color:#555;}
    .footer-bottom a:hover{color:#aaa;}
    .disclaimer{background:#111;border-top:1px solid #222;padding:12px 40px;text-align:center;font-size:11px;color:#444;}
    @media(max-width:900px){.blog-grid{grid-template-columns:1fr 1fr;}.card-wide{grid-column:span 2;flex-direction:column;}.card-wide .card-img,.card-wide .card-img-placeholder{width:100%;aspect-ratio:16/10;border-right:none;border-bottom:var(--border);}.hero{grid-template-columns:1fr;}.stats-bar{grid-template-columns:repeat(2,1fr);}.newsletter{grid-template-columns:1fr;}.footer-inner{grid-template-columns:1fr 1fr;}}
    .hamburger{display:none;flex-direction:column;justify-content:space-between;width:24px;height:18px;background:none;border:none;cursor:pointer;padding:0;}
    .hamburger span{display:block;height:2px;background:#ccc;border-radius:2px;transition:all .3s;}
    .hamburger.open span:nth-child(1){transform:translateY(8px) rotate(45deg);}
    .hamburger.open span:nth-child(2){opacity:0;}
    .hamburger.open span:nth-child(3){transform:translateY(-8px) rotate(-45deg);}
    .mobile-menu{display:none;position:fixed;top:58px;left:0;right:0;background:var(--black);z-index:99;border-bottom:2px solid var(--accent);padding:16px 0;}
    .mobile-menu.open{display:block;}
    .mobile-menu ul{list-style:none;display:flex;flex-direction:column;}
    .mobile-menu ul li a{display:block;padding:12px 24px;color:#ccc;font-size:13px;font-weight:500;letter-spacing:1.5px;text-transform:uppercase;border-bottom:1px solid #1a1a1a;transition:color .2s,background .2s;}
    .mobile-menu ul li a:hover{color:#fff;background:#1a1a1a;}
    .mobile-menu ul li:last-child a{background:var(--accent);color:#fff;border-bottom:none;margin:12px 24px 0;text-align:center;}
    @media(max-width:600px){
      nav{padding:0 16px;}
      .nav-links{display:none;}
      .hamburger{display:flex;}
      .blog-grid{grid-template-columns:1fr;}
      .card-wide{grid-column:span 1;flex-direction:column;}
      .card-wide .card-img,.card-wide .card-img-placeholder{width:100%;aspect-ratio:16/10;border-right:none;border-bottom:var(--border);}
      .hero{padding:28px 16px 24px;}
      .hero-title{font-size:clamp(28px,8vw,42px);}
      .stats-bar{grid-template-columns:1fr 1fr;}
      .stat-item{padding:16px;}
      .stat-num{font-size:32px;}
      .site-wrap{padding:0 12px;}
      .section-header{padding:24px 0 12px;}
      .newsletter{padding:24px 16px;}
      .newsletter-title{font-size:28px;}
      .newsletter-form{flex-direction:column;}
      .newsletter-form input{border-right:1.5px solid #333;border-bottom:none;}
      .newsletter-form button{width:100%;}
      .footer-inner{grid-template-columns:1fr;gap:24px;padding:24px 0;}
      footer{padding:24px 16px;}
      .footer-bottom{flex-direction:column;gap:8px;text-align:center;}
      .disclaimer{padding:12px 16px;}
    }
  </style>
</head>
<body>
<nav>
  <a href="index.php" class="nav-logo">Tesla<span>Semi</span>.com</a>
  <ul class="nav-links">
    <?php foreach($nav['links'] as $link): ?>
    <li><a href="<?= htmlspecialchars($link['url']) ?>"><?= htmlspecialchars($link['label']) ?></a></li>
    <?php endforeach; ?>
    <li><a href="#" class="nav-cta">Subscribe</a></li>
  </ul>
  <button class="hamburger" id="hamburger" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</nav>
<div class="mobile-menu" id="mobileMenu">
  <ul>
    <?php foreach($nav['links'] as $link): ?>
    <li><a href="<?= htmlspecialchars($link['url']) ?>"><?= htmlspecialchars($link['label']) ?></a></li>
    <?php endforeach; ?>
    <li><a href="#">Subscribe</a></li>
  </ul>
</div>
<script>
  const btn = document.getElementById('hamburger');
  const menu = document.getElementById('mobileMenu');
  btn.addEventListener('click', () => {
    btn.classList.toggle('open');
    menu.classList.toggle('open');
  });
</script>

<div class="ticker-wrap">
  <div class="ticker-track">
    <?php $tickerItems = !empty($ticker['items']) ? $ticker['items'] : ['Tesla Semi begins high-volume production in 2026','First public Megacharger opens in Los Angeles — 750 kW charging','Semi Long Range: 500 miles at 82,000 lbs GCW']; ?>
    <?php foreach($tickerItems as $item): ?><span><?= htmlspecialchars($item) ?></span><?php endforeach; ?>
    <?php foreach($tickerItems as $item): ?><span><?= htmlspecialchars($item) ?></span><?php endforeach; ?>
  </div>
</div>

<?php if ($featured): ?>
<div class="hero">
  <div>
    <div class="hero-tag"><?= htmlspecialchars($featured['category']??'News') ?> — <?= htmlspecialchars($featured['date']??'') ?></div>
    <h1 class="hero-title"><?= htmlspecialchars($featured['title']) ?></h1>
    <p class="hero-excerpt"><?= htmlspecialchars($featured['excerpt']??'') ?></p>
    <div class="hero-meta">
      <span>By <?= htmlspecialchars($featured['author']??'') ?></span>
      <span><?= htmlspecialchars($featured['read_time']??'') ?></span>
    </div>
    <a href="article.php?slug=<?= htmlspecialchars($featured['slug']??'') ?>" class="btn">Read Full Story</a>
  </div>
  <div class="hero-img-wrap" style="display:flex;flex-direction:column;">
    <?php if (!empty($featured['image'])): ?>
      <img src="<?= htmlspecialchars($featured['image']) ?>" alt="<?= htmlspecialchars($featured['title']) ?>" style="flex:1;"/>
    <?php else: ?>
      <div class="hero-img-placeholder" style="flex:1;"></div>
    <?php endif; ?>
    <?php if (!empty($featured['photo_credit'])): ?>
      <div style="background:#0a0a0a;padding:5px 0;text-align:right;font-size:10px;color:#555;">
        <?php if (!empty($featured['photo_credit_url'])): ?>
          <a href="<?= htmlspecialchars($featured['photo_credit_url']) ?>" target="_blank" rel="noopener" style="color:#666;text-decoration:none;">Photo: <?= htmlspecialchars($featured['photo_credit']) ?></a>
        <?php else: ?>
          Photo: <?= htmlspecialchars($featured['photo_credit']) ?>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<div class="site-wrap">
  <div class="stats-bar" style="margin-top:40px;">
    <div class="stat-item"><div class="stat-num">500mi</div><div class="stat-label">Long Range at Full Load</div></div>
    <div class="stat-item"><div class="stat-num">1.2MW</div><div class="stat-label">Peak Megacharger Speed</div></div>
    <div class="stat-item"><div class="stat-num">75K+</div><div class="stat-label">Superchargers Globally</div></div>
    <div class="stat-item"><div class="stat-num">2026</div><div class="stat-label">Mass Production Year</div></div>
  </div>

  <?php if (!empty($grid)): ?>
  <div class="section-header">
    <span class="section-title">Recent News</span>
    <a href="#" class="section-link">View All Articles</a>
  </div>
  <!-- Row 1: wide card + 1 regular -->
  <div class="blog-grid" style="margin-bottom:20px;">
    <?php foreach (array_slice($grid, 0, 2) as $i => $a): ?>
    <?php if ($i === 0): ?>
    <a href="article.php?slug=<?= htmlspecialchars($a['slug']??'') ?>" class="card card-wide">
      <?php if (!empty($a['image'])): ?>
        <img class="card-img" src="<?= htmlspecialchars($a['image']) ?>" alt="" style="width:45%;flex-shrink:0;aspect-ratio:auto;border-bottom:none;border-right:1.5px solid #0a0a0a;"/>
      <?php else: ?>
        <div class="card-img-placeholder" style="width:45%;flex-shrink:0;aspect-ratio:auto;border-bottom:none;border-right:1.5px solid #0a0a0a;"></div>
      <?php endif; ?>
      <div class="card-content" style="flex:1;display:flex;flex-direction:column;">
        <div class="card-header"><div class="card-dots"><span></span><span></span><span></span></div><div class="card-num">[No. <?= htmlspecialchars($a['num']??'') ?>]</div></div>
        <div class="card-body">
          <div class="card-category"><?= htmlspecialchars($a['category']??'') ?></div>
          <div class="card-meta"><span><?= htmlspecialchars($a['date']??'') ?></span><span><?= htmlspecialchars($a['read_time']??'') ?></span></div>
          <div class="card-title" style="font-size:24px;"><?= htmlspecialchars($a['title']) ?></div>
          <div class="card-excerpt"><?= htmlspecialchars($a['excerpt']??'') ?></div>
          <div class="card-author">by <strong><?= htmlspecialchars($a['author']??'') ?></strong></div>
        </div>
      </div>
    </a>
    <?php else: ?>
    <a href="article.php?slug=<?= htmlspecialchars($a['slug']??'') ?>" class="card">
      <div class="card-header"><div class="card-dots"><span></span><span></span><span></span></div><div class="card-num">[No. <?= htmlspecialchars($a['num']??'') ?>]</div></div>
      <?php if (!empty($a['image'])): ?><img class="card-img" src="<?= htmlspecialchars($a['image']) ?>" alt=""/><?php else: ?><div class="card-img-placeholder"></div><?php endif; ?>
      <?php if (!empty($a['photo_credit'])): ?><div style="font-size:10px;color:#888;padding:4px 10px;background:var(--card-bg);text-align:right;"><?php if (!empty($a['photo_credit_url'])): ?><a href="<?= htmlspecialchars($a['photo_credit_url']) ?>" style="color:#888;text-decoration:none;" onclick="event.stopPropagation()">Photo: <?= htmlspecialchars($a['photo_credit']) ?></a><?php else: ?>Photo: <?= htmlspecialchars($a['photo_credit']) ?><?php endif; ?></div><?php endif; ?>
      <div class="card-body">
        <div class="card-category"><?= htmlspecialchars($a['category']??'') ?></div>
        <div class="card-meta"><span><?= htmlspecialchars($a['date']??'') ?></span><span><?= htmlspecialchars($a['read_time']??'') ?></span></div>
        <div class="card-title"><?= htmlspecialchars($a['title']) ?></div>
        <div class="card-excerpt"><?= htmlspecialchars($a['excerpt']??'') ?></div>
        <div class="card-author">by <strong><?= htmlspecialchars($a['author']??'') ?></strong></div>
      </div>
    </a>
    <?php endif; ?>
    <?php endforeach; ?>
  </div>
  <!-- Row 2: up to 2 regular cards -->
  <?php if (count($grid) > 2): ?>
  <div class="blog-grid" style="grid-template-columns:repeat(2,1fr);margin-bottom:48px;">
    <?php foreach (array_slice($grid, 2, 2) as $a): ?>
    <a href="article.php?slug=<?= htmlspecialchars($a['slug']??'') ?>" class="card">
      <div class="card-header"><div class="card-dots"><span></span><span></span><span></span></div><div class="card-num">[No. <?= htmlspecialchars($a['num']??'') ?>]</div></div>
      <?php if (!empty($a['image'])): ?><img class="card-img" src="<?= htmlspecialchars($a['image']) ?>" alt=""/><?php else: ?><div class="card-img-placeholder"></div><?php endif; ?>
      <?php if (!empty($a['photo_credit'])): ?><div style="font-size:10px;color:#888;padding:4px 10px;background:var(--card-bg);text-align:right;"><?php if (!empty($a['photo_credit_url'])): ?><a href="<?= htmlspecialchars($a['photo_credit_url']) ?>" style="color:#888;text-decoration:none;" onclick="event.stopPropagation()">Photo: <?= htmlspecialchars($a['photo_credit']) ?></a><?php else: ?>Photo: <?= htmlspecialchars($a['photo_credit']) ?><?php endif; ?></div><?php endif; ?>
      <div class="card-body">
        <div class="card-category"><?= htmlspecialchars($a['category']??'') ?></div>
        <div class="card-meta"><span><?= htmlspecialchars($a['date']??'') ?></span><span><?= htmlspecialchars($a['read_time']??'') ?></span></div>
        <div class="card-title"><?= htmlspecialchars($a['title']) ?></div>
        <div class="card-excerpt"><?= htmlspecialchars($a['excerpt']??'') ?></div>
        <div class="card-author">by <strong><?= htmlspecialchars($a['author']??'') ?></strong></div>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <?php elseif (empty($articles)): ?>
  <div class="empty-state">
    <h2>No Articles Published Yet</h2>
    <p>Head to the <a href="admin.php" style="color:var(--accent);">Admin Panel</a> to write and publish your first article.</p>
  </div>
  <?php endif; ?>

  <div class="newsletter">
    <div>
      <div class="newsletter-title">Stay in the<br><span>Fast Lane.</span></div>
      <div class="newsletter-sub">No fluff. Just the latest on Tesla Semi — straight to your inbox.</div>
    </div>
    <div>
      <div class="newsletter-form">
        <input type="email" placeholder="Your email address"/>
        <button type="button">Subscribe</button>
      </div>
      <p style="color:#444;font-size:11px;margin-top:10px;">No spam. Unsubscribe anytime.</p>
    </div>
  </div>

  <?php if (!empty($more)): ?>
  <div class="section-header"><span class="section-title">More Articles</span><a href="#" class="section-link">View Archive</a></div>
  <div class="blog-grid" style="margin-bottom:60px;">
    <?php foreach ($more as $a): ?>
    <a href="article.php?slug=<?= htmlspecialchars($a['slug']??'') ?>" class="card">
      <div class="card-header"><div class="card-dots"><span></span><span></span><span></span></div><div class="card-num">[No. <?= htmlspecialchars($a['num']??'') ?>]</div></div>
      <?php if (!empty($a['image'])): ?><img class="card-img" src="<?= htmlspecialchars($a['image']) ?>" alt=""/><?php else: ?><div class="card-img-placeholder"></div><?php endif; ?>
      <?php if (!empty($a['photo_credit'])): ?><div style="font-size:10px;color:#888;padding:4px 10px;background:var(--card-bg);text-align:right;"><?php if (!empty($a['photo_credit_url'])): ?><a href="<?= htmlspecialchars($a['photo_credit_url']) ?>" style="color:#888;text-decoration:none;" onclick="event.stopPropagation()">Photo: <?= htmlspecialchars($a['photo_credit']) ?></a><?php else: ?>Photo: <?= htmlspecialchars($a['photo_credit']) ?><?php endif; ?></div><?php endif; ?>
      <div class="card-body">
        <div class="card-category"><?= htmlspecialchars($a['category']??'') ?></div>
        <div class="card-meta"><span><?= htmlspecialchars($a['date']??'') ?></span><span><?= htmlspecialchars($a['read_time']??'') ?></span></div>
        <div class="card-title"><?= htmlspecialchars($a['title']) ?></div>
        <div class="card-author">by <strong><?= htmlspecialchars($a['author']??'') ?></strong></div>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<footer>
  <div class="footer-inner">
    <div>
      <div class="footer-brand-name">Tesla<span>Semi</span>.com</div>
      <div class="footer-brand-desc">The internet's home for Tesla Semi news, charging infrastructure updates, pilot program results, and everything in between. Independent. Passionate. Plugged in.</div>
    </div>
    <div class="footer-col"><h4>Coverage</h4><ul><li><a href="#">News</a></li><li><a href="#">Charging</a></li><li><a href="#">Production</a></li><li><a href="#">Pilot Programs</a></li><li><a href="#">Europe</a></li><li><a href="#">Specs & Data</a></li></ul></div>
    <div class="footer-col"><h4>Company</h4><ul><li><a href="#">About</a></li><li><a href="#">Contact</a></li><li><a href="#">Advertise</a></li><li><a href="#">Newsletter</a></li></ul></div>
    <div class="footer-col"><h4>Follow</h4><ul><li><a href="#">X / Twitter</a></li><li><a href="#">LinkedIn</a></li><li><a href="#">YouTube</a></li><li><a href="#">Instagram</a></li></ul></div>
  </div>
  <div class="footer-bottom">
    <span>© 2026 TeslaSemi.com — All rights reserved</span>
    <span><a href="#">Privacy Policy</a> &nbsp;·&nbsp; <a href="#">Terms of Use</a> &nbsp;·&nbsp; <a href="admin.php">Admin</a></span>
  </div>
</footer>
<div class="disclaimer">TeslaSemi.com is an independent news publication and is not affiliated with, endorsed by, or sponsored by Tesla, Inc.</div>
</body>
</html>
