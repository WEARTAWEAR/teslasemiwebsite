<?php
define('TICKER_FILE', 'data/ticker.json');
define('NAV_FILE',    'data/nav.json');
define('VIDEOS_FILE', 'data/videos.json');
function loadTicker() {
    if (!file_exists(TICKER_FILE)) return ['items'=>['Tesla Semi begins high-volume production in 2026','First public Megacharger opens in Los Angeles — 750 kW charging','Semi Long Range: 500 miles at 82,000 lbs GCW']];
    return json_decode(file_get_contents(TICKER_FILE), true) ?? ['items'=>[]];
}
function loadNav() {
    if (!file_exists(NAV_FILE)) return ['links'=>[['label'=>'News','url'=>'index.php'],['label'=>'Charging','url'=>'#'],['label'=>'Production','url'=>'#'],['label'=>'Video','url'=>'video.php'],['label'=>'Specs','url'=>'#']]];
    return json_decode(file_get_contents(NAV_FILE), true) ?? ['links'=>[]];
}
function loadVideos() {
    if (!file_exists(VIDEOS_FILE)) return [];
    return json_decode(file_get_contents(VIDEOS_FILE), true) ?? [];
}
function getYouTubeId($url) {
    preg_match('/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|v\/))([a-zA-Z0-9_-]{11})/', $url, $m);
    return $m[1] ?? null;
}
$ticker  = loadTicker();
$nav     = loadNav();
$videos  = array_values(array_filter(loadVideos(), fn($v) => $v['published'] ?? true));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>TeslaSemi.com — Video Hub</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;700&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet">
  <style>
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
    :root{--bg:#e8e8e4;--card-bg:#f2f2ef;--black:#0a0a0a;--dark:#1a1a1a;--mid:#555;--light:#999;--accent:#c8102e;--border:1.5px solid #0a0a0a;}
    body{background:var(--bg);color:var(--dark);font-family:'DM Sans',sans-serif;font-size:15px;line-height:1.6;min-height:100vh;}
    a{text-decoration:none;color:inherit;}

    nav{background:var(--black);color:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 40px;height:56px;border-bottom:2px solid var(--accent);position:sticky;top:0;z-index:100;}
    .nav-logo{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:2px;color:#fff;}
    .nav-logo span{color:var(--accent);}
    .nav-links{display:flex;gap:28px;list-style:none;}
    .nav-links a{color:#ccc;font-size:12px;font-weight:500;letter-spacing:1.5px;text-transform:uppercase;transition:color .2s;}
    .nav-links a:hover{color:#fff;}
    .nav-links a.active{color:#fff;}
    .nav-cta{background:var(--accent);color:#fff!important;padding:6px 16px;font-weight:700!important;}
    .hamburger{display:none;flex-direction:column;justify-content:space-between;width:24px;height:18px;background:none;border:none;cursor:pointer;padding:0;}
    .hamburger span{display:block;height:2px;background:#ccc;border-radius:2px;transition:all .3s;}
    .hamburger.open span:nth-child(1){transform:translateY(8px) rotate(45deg);}
    .hamburger.open span:nth-child(2){opacity:0;}
    .hamburger.open span:nth-child(3){transform:translateY(-8px) rotate(-45deg);}
    .mobile-menu{display:none;position:fixed;top:58px;left:0;right:0;background:var(--black);z-index:99;border-bottom:2px solid var(--accent);padding:16px 0;}
    .mobile-menu.open{display:block;}
    .mobile-menu ul{list-style:none;display:flex;flex-direction:column;}
    .mobile-menu ul li a{display:block;padding:12px 24px;color:#ccc;font-size:13px;font-weight:500;letter-spacing:1.5px;text-transform:uppercase;border-bottom:1px solid #1a1a1a;transition:color .2s,background .2s;}
    .mobile-menu ul li a:hover{color:#fff;background:#1a1a1a;}
    .mobile-menu ul li:last-child a{background:var(--accent);color:#fff;border-bottom:none;margin:12px 24px 0;text-align:center;}

    .ticker-wrap{background:var(--accent);overflow:hidden;height:34px;display:flex;align-items:center;border-bottom:var(--border);}
    .ticker-track{display:flex;animation:ticker 35s linear infinite;white-space:nowrap;padding-left:24px;}
    .ticker-track span{font-size:11px;font-weight:600;color:#fff;padding:0 40px;letter-spacing:.5px;}
    .ticker-track span::before{content:"●";margin-right:12px;font-size:8px;}
    @keyframes ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}

    .page-hero{background:var(--black);color:#fff;padding:48px 40px 40px;border-bottom:var(--border);}
    .page-hero-tag{font-size:11px;font-weight:700;letter-spacing:3px;text-transform:uppercase;color:var(--accent);margin-bottom:12px;}
    .page-hero-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(36px,5vw,56px);letter-spacing:3px;line-height:1;}

    .site-wrap{max-width:1300px;margin:0 auto;padding:0 24px;}
    .section-header{display:flex;align-items:baseline;justify-content:space-between;padding:36px 0 16px;border-bottom:var(--border);margin-bottom:24px;}
    .section-title{font-family:'Bebas Neue',sans-serif;font-size:32px;letter-spacing:2px;color:var(--black);}
    .section-count{font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--black);border-bottom:1.5px solid var(--black);padding-bottom:2px;}

    .video-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-bottom:60px;}
    .vcard{background:var(--card-bg);border:var(--border);display:flex;flex-direction:column;transition:transform .2s,box-shadow .2s;}
    .vcard:hover{transform:translateY(-3px);box-shadow:4px 4px 0 var(--black);}
    .vcard-header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-bottom:var(--border);background:var(--black);}
    .vcard-dots{display:flex;gap:5px;}
    .vcard-dots span{width:8px;height:8px;border-radius:50%;border:1.5px solid #555;display:block;}
    .vcard-num{font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--accent);}
    .vthumb{width:100%;aspect-ratio:16/10;position:relative;overflow:hidden;border-bottom:var(--border);display:block;}
    .vthumb img{width:100%;height:100%;object-fit:cover;transition:opacity .3s;}
    .vthumb:hover img{opacity:.75;}
    .vplay{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:48px;height:48px;background:rgba(200,16,46,.92);border-radius:50%;display:flex;align-items:center;justify-content:center;transition:transform .2s;}
    .vthumb:hover .vplay{transform:translate(-50%,-50%) scale(1.1);}
    .vplay-tri{width:0;height:0;border-top:10px solid transparent;border-bottom:10px solid transparent;border-left:18px solid #fff;margin-left:4px;}
    .vcard-body{padding:14px 16px 18px;flex:1;display:flex;flex-direction:column;gap:6px;}
    .vcard-cat{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--accent);}
    .vcard-title{font-family:'DM Serif Display',serif;font-size:17px;line-height:1.25;color:var(--black);margin-top:2px;}
    .vcard-desc{font-size:13px;color:var(--mid);line-height:1.6;margin-top:2px;}
    .vcard-credit{font-size:11px;color:var(--light);margin-top:auto;padding-top:10px;border-top:1px solid #ddd;}
    .vcard-credit a{color:var(--accent);font-weight:600;transition:opacity .2s;}
    .vcard-credit a:hover{opacity:.75;}

    .empty-state{text-align:center;padding:80px 40px;color:var(--mid);}
    .empty-state h2{font-family:'Bebas Neue',sans-serif;font-size:32px;margin-bottom:12px;color:var(--black);}

    footer{background:var(--black);color:#fff;border-top:2px solid var(--accent);padding:40px;}
    .footer-inner{max-width:1300px;margin:0 auto;display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:40px;padding-bottom:32px;border-bottom:1px solid #222;}
    .footer-brand-name{font-family:'Bebas Neue',sans-serif;font-size:28px;letter-spacing:2px;margin-bottom:10px;}
    .footer-brand-name span{color:var(--accent);}
    .footer-brand-desc{color:#666;font-size:13px;line-height:1.7;max-width:280px;}
    .footer-col h4{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#888;margin-bottom:14px;}
    .footer-col ul{list-style:none;}
    .footer-col ul li{margin-bottom:8px;}
    .footer-col ul li a{color:#aaa;font-size:13px;transition:color .2s;}
    .footer-col ul li a:hover{color:#fff;}
    .footer-bottom{max-width:1300px;margin:0 auto;padding-top:20px;display:flex;justify-content:space-between;font-size:12px;color:#555;}
    .footer-bottom a{color:#555;}
    .footer-bottom a:hover{color:#aaa;}
    .disclaimer{background:#111;border-top:1px solid #222;padding:12px 40px;text-align:center;font-size:11px;color:#444;}

    @media(max-width:900px){.video-grid{grid-template-columns:1fr 1fr;}.footer-inner{grid-template-columns:1fr 1fr;}}
    @media(max-width:600px){
      nav{padding:0 16px;}.nav-links{display:none;}.hamburger{display:flex;}
      .video-grid{grid-template-columns:1fr;}
      .page-hero{padding:28px 16px 24px;}
      .site-wrap{padding:0 12px;}
      .footer-inner{grid-template-columns:1fr;}
      footer{padding:24px 16px;}
      .footer-bottom{flex-direction:column;gap:8px;text-align:center;}
    }
  </style>
</head>
<body>

<nav>
  <a href="index.php" class="nav-logo">Tesla<span>Semi</span>.com</a>
  <ul class="nav-links">
    <?php foreach($nav['links'] as $link): ?>
    <li><a href="<?= htmlspecialchars($link['url']) ?>" <?= (basename($_SERVER['PHP_SELF'])==='video.php' && strtolower($link['label'])==='video') ? 'class="active"' : '' ?>><?= htmlspecialchars($link['label']) ?></a></li>
    <?php endforeach; ?>
    <li><a href="#" class="nav-cta">Subscribe</a></li>
  </ul>
  <button class="hamburger" id="hamburger" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</nav>
<div class="mobile-menu" id="mobileMenu">
  <ul>
    <?php foreach($nav['links'] as $link): ?>
    <li><a href="<?= htmlspecialchars($link['url']) ?>"><?= htmlspecialchars($link['label']) ?></a></li>
    <?php endforeach; ?>
    <li><a href="#">Subscribe</a></li>
  </ul>
</div>
<script>
  const btn = document.getElementById('hamburger');
  const menu = document.getElementById('mobileMenu');
  btn.addEventListener('click', () => { btn.classList.toggle('open'); menu.classList.toggle('open'); });
</script>

<div class="ticker-wrap">
  <div class="ticker-track">
    <?php $tickerItems = !empty($ticker['items']) ? $ticker['items'] : ['Tesla Semi begins high-volume production in 2026','First public Megacharger opens in Los Angeles — 750 kW charging','Semi Long Range: 500 miles at 82,000 lbs GCW']; ?>
    <?php foreach($tickerItems as $item): ?><span><?= htmlspecialchars($item) ?></span><?php endforeach; ?>
    <?php foreach($tickerItems as $item): ?><span><?= htmlspecialchars($item) ?></span><?php endforeach; ?>
  </div>
</div>

<div class="page-hero">
  <div class="page-hero-tag">Video</div>
  <div class="page-hero-title">Tesla Semi — Video Hub</div>
</div>

<div class="site-wrap">
  <?php if (!empty($videos)): ?>
  <div class="section-header">
    <span class="section-title">All Videos</span>
    <span class="section-count"><?= count($videos) ?> Video<?= count($videos)!==1?'s':'' ?></span>
  </div>
  <div class="video-grid">
    <?php foreach($videos as $i => $v):
      $ytid = '';
      if (!empty($v['youtube_url'])) {
        preg_match('/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|v\/))([a-zA-Z0-9_-]{11})/', $v['youtube_url'], $m);
        $ytid = $m[1] ?? '';
      }
      $thumb = $ytid ? "https://img.youtube.com/vi/{$ytid}/hqdefault.jpg" : '';
      $num   = str_pad($i+1, 2, '0', STR_PAD_LEFT);
    ?>
    <div class="vcard">
      <div class="vcard-header">
        <div class="vcard-dots"><span></span><span></span><span></span></div>
        <div class="vcard-num">[No. <?= $num ?>]</div>
      </div>
      <a href="<?= htmlspecialchars($v['youtube_url']??'#') ?>" target="_blank" rel="noopener" class="vthumb">
        <?php if ($thumb): ?>
          <img src="<?= htmlspecialchars($thumb) ?>" alt="<?= htmlspecialchars($v['title']??'') ?>"/>
        <?php else: ?>
          <div style="width:100%;height:100%;background:#111;"></div>
        <?php endif; ?>
        <div class="vplay"><div class="vplay-tri"></div></div>
      </a>
      <div class="vcard-body">
        <div class="vcard-cat"><?= htmlspecialchars($v['category']??'Video') ?></div>
        <div class="vcard-title"><?= htmlspecialchars($v['title']??'') ?></div>
        <?php if (!empty($v['description'])): ?>
        <div class="vcard-desc"><?= htmlspecialchars($v['description']) ?></div>
        <?php endif; ?>
        <?php if (!empty($v['credit_name'])): ?>
        <div class="vcard-credit">
          Credit:&nbsp;
          <?php if (!empty($v['credit_url'])): ?>
            <a href="<?= htmlspecialchars($v['credit_url']) ?>" target="_blank" rel="noopener"><?= htmlspecialchars($v['credit_name']) ?></a>
          <?php else: ?>
            <?= htmlspecialchars($v['credit_name']) ?>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <div class="empty-state">
    <h2>No Videos Yet</h2>
    <p>Head to the <a href="admin.php?view=videos" style="color:var(--accent);">Admin Panel</a> to add your first video.</p>
  </div>
  <?php endif; ?>
</div>

<footer>
  <div class="footer-inner">
    <div>
      <div class="footer-brand-name">Tesla<span>Semi</span>.com</div>
      <div class="footer-brand-desc">The internet's home for Tesla Semi news, charging infrastructure updates, pilot program results, and everything in between. Independent. Passionate. Plugged in.</div>
    </div>
    <div class="footer-col"><h4>Coverage</h4><ul><li><a href="index.php">News</a></li><li><a href="#">Charging</a></li><li><a href="#">Production</a></li><li><a href="video.php">Video</a></li><li><a href="#">Specs & Data</a></li></ul></div>
    <div class="footer-col"><h4>Company</h4><ul><li><a href="#">About</a></li><li><a href="#">Contact</a></li><li><a href="#">Advertise</a></li><li><a href="#">Newsletter</a></li></ul></div>
    <div class="footer-col"><h4>Follow</h4><ul><li><a href="#">X / Twitter</a></li><li><a href="#">LinkedIn</a></li><li><a href="#">YouTube</a></li><li><a href="#">Instagram</a></li></ul></div>
  </div>
  <div class="footer-bottom">
    <span>© 2026 TeslaSemi.com — All rights reserved</span>
    <span><a href="#">Privacy Policy</a> &nbsp;·&nbsp; <a href="#">Terms of Use</a> &nbsp;·&nbsp; <a href="admin.php">Admin</a></span>
  </div>
</footer>
<div class="disclaimer">TeslaSemi.com is an independent news publication and is not affiliated with, endorsed by, or sponsored by Tesla, Inc.</div>
</body>
</html>
