<?php
define('ARTICLES_FILE', 'data/articles.json');
function loadArticles() {
    if (!file_exists(ARTICLES_FILE)) return [];
    return json_decode(file_get_contents(ARTICLES_FILE), true) ?? [];
}
$articles = loadArticles();
$slug = $_GET['slug'] ?? '';
$article = null;
foreach ($articles as $a) {
    if (($a['slug'] ?? '') === $slug && ($a['published'] ?? false)) { $article = $a; break; }
}
if (!$article) { header('HTTP/1.0 404 Not Found'); die('<h1>Article not found</h1>'); }
$related = array_filter($articles, fn($a) => $a['id'] !== $article['id'] && ($a['published']??false));
$related = array_slice(array_values($related), 0, 3);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title><?= htmlspecialchars($article['title']) ?> — TeslaSemi.com</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,700;1,400&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{--bg:#e8e8e4;--card-bg:#f2f2ef;--black:#0a0a0a;--dark:#1a1a1a;--mid:#555;--light:#999;--accent:#c8102e;--border:1.5px solid #0a0a0a;}
body{background:var(--bg);color:var(--dark);font-family:'DM Sans',sans-serif;font-size:16px;line-height:1.7;}
nav{background:var(--black);color:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 40px;height:56px;border-bottom:2px solid var(--accent);position:sticky;top:0;z-index:100;}
.nav-logo{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:2px;color:#fff;text-decoration:none;}
.nav-logo span{color:var(--accent);}
.nav-links{display:flex;gap:28px;list-style:none;}
.nav-links a{color:#ccc;text-decoration:none;font-size:12px;font-weight:500;letter-spacing:1.5px;text-transform:uppercase;transition:color .2s;}
.nav-links a:hover{color:#fff;}
.article-hero{background:var(--black);padding:48px 0 0;}
.article-wrap{max-width:780px;margin:0 auto;padding:0 24px;}
.article-category{font-size:11px;font-weight:700;letter-spacing:3px;text-transform:uppercase;color:var(--accent);margin-bottom:16px;}
.article-title{font-family:'DM Serif Display',serif;font-size:clamp(32px,5vw,52px);color:#fff;line-height:1.1;margin-bottom:20px;}
.article-meta{display:flex;gap:20px;font-size:13px;color:#888;padding-bottom:32px;}
.article-meta span{color:#aaa;}
.article-img{width:100%;max-width:900px;margin:0 auto;display:block;aspect-ratio:16/9;object-fit:cover;border-bottom:2px solid var(--accent);}
.article-img-placeholder{width:100%;max-width:900px;margin:0 auto;display:block;aspect-ratio:16/9;background:var(--black);}
.article-body{max-width:720px;margin:48px auto;padding:0 24px;}
.article-body p{margin-bottom:20px;font-size:17px;line-height:1.8;color:#222;}
.article-body h2{font-family:'DM Serif Display',serif;font-size:26px;margin:36px 0 16px;color:var(--black);}
.article-body strong{color:var(--black);font-weight:700;}
.article-body ul{margin:0 0 20px 24px;}
.article-body li{margin-bottom:8px;font-size:17px;}
.divider{border:none;border-top:1.5px solid var(--black);max-width:720px;margin:0 auto 40px;}
.related{max-width:1200px;margin:0 auto;padding:0 24px 60px;}
.section-header{display:flex;align-items:baseline;justify-content:space-between;padding:36px 0 16px;border-bottom:var(--border);margin-bottom:24px;}
.section-title{font-family:'Bebas Neue',sans-serif;font-size:28px;letter-spacing:2px;}
.related-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;}
.card{background:var(--card-bg);border:var(--border);display:flex;flex-direction:column;text-decoration:none;color:inherit;transition:transform .2s,box-shadow .2s;}
.card:hover{transform:translateY(-3px);box-shadow:4px 4px 0 var(--black);}
.card-header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-bottom:var(--border);background:var(--black);}
.card-dots{display:flex;gap:5px;}
.card-dots span{width:8px;height:8px;border-radius:50%;border:1.5px solid #555;display:block;}
.card-num{font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--accent);}
.card-img-placeholder{width:100%;aspect-ratio:16/10;background:var(--black);border-bottom:var(--border);}
.card-img{width:100%;aspect-ratio:16/10;object-fit:cover;border-bottom:var(--border);}
.card-body{padding:14px 16px 18px;flex:1;display:flex;flex-direction:column;gap:6px;}
.card-category{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--accent);}
.card-title{font-family:'DM Serif Display',serif;font-size:17px;line-height:1.25;color:var(--black);margin-top:4px;}
footer{background:var(--black);color:#fff;border-top:2px solid var(--accent);padding:32px 40px;text-align:center;}
.footer-logo{font-family:'Bebas Neue',sans-serif;font-size:24px;letter-spacing:2px;margin-bottom:8px;}
.footer-logo span{color:var(--accent);}
.footer-note{color:#555;font-size:11px;}
</style>
</head>
<body>
<nav>
  <a href="index.php" class="nav-logo">Tesla<span>Semi</span>.com</a>
  <ul class="nav-links">
    <li><a href="index.php">News</a></li>
    <li><a href="#">Charging</a></li>
    <li><a href="#">Production</a></li>
    <li><a href="#">Pilot Programs</a></li>
    <li><a href="#">Specs</a></li>
  </ul>
</nav>

<div class="article-hero">
  <div class="article-wrap">
    <div class="article-category"><?= htmlspecialchars($article['category']??'News') ?></div>
    <h1 class="article-title"><?= htmlspecialchars($article['title']) ?></h1>
    <div class="article-meta">
      <span>By <strong style="color:#fff"><?= htmlspecialchars($article['author']??'') ?></strong></span>
      <span><?= htmlspecialchars($article['date']??'') ?></span>
      <span><?= htmlspecialchars($article['read_time']??'4 min read') ?></span>
    </div>
  </div>
  <?php if (!empty($article['image'])): ?>
    <img class="article-img" src="<?= htmlspecialchars($article['image']) ?>" alt="<?= htmlspecialchars($article['title']) ?>"/>
  <?php else: ?>
    <div class="article-img-placeholder"></div>
  <?php endif; ?>
</div>

<div class="article-body">
  <?php if (!empty($article['content'])): ?>
    <?= $article['content'] ?>
  <?php else: ?>
    <p><?= nl2br(htmlspecialchars($article['excerpt']??'')) ?></p>
  <?php endif; ?>
</div>

<hr class="divider"/>

<?php if (!empty($related)): ?>
<div class="related">
  <div class="section-header"><span class="section-title">More Articles</span></div>
  <div class="related-grid">
    <?php foreach ($related as $r): ?>
    <a href="article.php?slug=<?= htmlspecialchars($r['slug']??'') ?>" class="card">
      <div class="card-header">
        <div class="card-dots"><span></span><span></span><span></span></div>
        <div class="card-num">[No. <?= htmlspecialchars($r['num']??'') ?>]</div>
      </div>
      <?php if (!empty($r['image'])): ?>
        <img class="card-img" src="<?= htmlspecialchars($r['image']) ?>" alt=""/>
      <?php else: ?>
        <div class="card-img-placeholder"></div>
      <?php endif; ?>
      <div class="card-body">
        <div class="card-category"><?= htmlspecialchars($r['category']??'') ?></div>
        <div class="card-title"><?= htmlspecialchars($r['title']) ?></div>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<footer>
  <div class="footer-logo">Tesla<span>Semi</span>.com</div>
  <div class="footer-note">Independent Tesla Semi news. Not affiliated with Tesla, Inc.</div>
</footer>
</body>
</html>
