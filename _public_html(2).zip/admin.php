<?php
// ── CONFIG ──────────────────────────────────────────────
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'teslasemi2026'); // password: "password" - CHANGE THIS
define('ARTICLES_FILE', 'data/articles.json');
define('TICKER_FILE', 'data/ticker.json');
define('UPLOADS_DIR', 'uploads/');
session_start();

// ── AUTH ────────────────────────────────────────────────
function isLoggedIn() { return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true; }

if (isset($_POST['login'])) {
    if ($_POST['username'] === ADMIN_USER && ($_POST['password'] === ADMIN_PASS)) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: admin.php'); exit;
    } else { $login_error = 'Invalid credentials.'; }
}
if (isset($_GET['logout'])) { session_destroy(); header('Location: admin.php'); exit; }

// ── DATA HELPERS ────────────────────────────────────────
function loadArticles() {
    if (!file_exists(ARTICLES_FILE)) return [];
    return json_decode(file_get_contents(ARTICLES_FILE), true) ?? [];
}
function saveArticles($articles) {
    if (!is_dir('data')) mkdir('data', 0755, true);
    file_put_contents(ARTICLES_FILE, json_encode($articles, JSON_PRETTY_PRINT));
}
function loadTicker() {
    if (!file_exists(TICKER_FILE)) return ['items'=>['Tesla Semi begins high-volume production in 2026','First public Megacharger opens in Los Angeles — 750 kW charging','Semi Long Range: 500 miles at 82,000 lbs GCW']];
    return json_decode(file_get_contents(TICKER_FILE), true) ?? ['items'=>[]];
}
function saveTicker($data) {
    if (!is_dir('data')) mkdir('data', 0755, true);
    file_put_contents(TICKER_FILE, json_encode($data, JSON_PRETTY_PRINT));
}
function generateSlug($title) {
    return strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title), '-'));
}

// ── ACTIONS (only when logged in) ───────────────────────
if (isLoggedIn()) {

    // Upload image
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        if (!is_dir(UPLOADS_DIR)) mkdir(UPLOADS_DIR, 0755, true);
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','webp','gif'];
        if (in_array($ext, $allowed)) {
            $fname = uniqid('img_') . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], UPLOADS_DIR . $fname);
            echo json_encode(['success' => true, 'url' => UPLOADS_DIR . $fname]);
            exit;
        }
    }

    // Save article
    if (isset($_POST['save_article'])) {
        $articles = loadArticles();
        $id = $_POST['article_id'] ?: uniqid('art_');
        $article = [
            'id'       => $id,
            'num'      => $_POST['num'],
            'title'    => $_POST['title'],
            'excerpt'  => $_POST['excerpt'],
            'content'  => $_POST['content'],
            'category' => $_POST['category'],
            'author'   => $_POST['author'],
            'date'     => $_POST['date'],
            'read_time'=> $_POST['read_time'],
            'image'    => $_POST['image_url'],
            'slug'     => generateSlug($_POST['title']),
            'published'=> isset($_POST['published']) ? true : false,
        ];
        // Update or insert
        $found = false;
        foreach ($articles as &$a) { if ($a['id'] === $id) { $a = $article; $found = true; break; } }
        if (!$found) array_unshift($articles, $article);
        saveArticles($articles);
        $success = 'Article saved successfully!';
    }

    // Delete article
    if (isset($_GET['delete'])) {
        $articles = loadArticles();
        $articles = array_filter($articles, fn($a) => $a['id'] !== $_GET['delete']);
        saveArticles(array_values($articles));
        header('Location: admin.php'); exit;
    }

    // Toggle publish
    if (isset($_GET['toggle'])) {
        $articles = loadArticles();
        foreach ($articles as &$a) {
            if ($a['id'] === $_GET['toggle']) { $a['published'] = !($a['published'] ?? false); break; }
        }
        saveArticles($articles);
        header('Location: admin.php'); exit;
    }

    // Save ticker
    if (isset($_POST['save_ticker'])) {
        $items = array_values(array_filter(array_map('trim', explode("\n", $_POST['ticker_items'] ?? '')), fn($s) => $s !== ''));
        saveTicker(['items' => $items]);
        $ticker_success = 'Ticker saved!';
    }
}

$articles = loadArticles();
$ticker = loadTicker();
$editing = null;
if (isset($_GET['edit'])) {
    foreach ($articles as $a) { if ($a['id'] === $_GET['edit']) { $editing = $a; break; } }
}
$view = isset($_GET['view']) ? $_GET['view'] : 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>TeslaSemi.com — Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;700&family=DM+Serif+Display&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --bg:#0f0f0f;
  --surface:#1a1a1a;
  --surface2:#222;
  --border:#2a2a2a;
  --border2:#333;
  --text:#f0f0f0;
  --muted:#888;
  --accent:#c8102e;
  --accent2:#e8143a;
  --green:#22c55e;
  --yellow:#eab308;
  --font-body:'DM Sans',sans-serif;
  --font-display:'Bebas Neue',sans-serif;
  --font-serif:'DM Serif Display',serif;
}
body{background:var(--bg);color:var(--text);font-family:var(--font-body);font-size:14px;line-height:1.6;min-height:100vh;}
a{color:inherit;text-decoration:none;}
input,textarea,select{background:var(--surface2);border:1.5px solid var(--border2);color:var(--text);font-family:var(--font-body);font-size:14px;padding:10px 14px;width:100%;outline:none;border-radius:0;transition:border-color .2s;}
input:focus,textarea:focus,select:focus{border-color:var(--accent);}
textarea{resize:vertical;min-height:120px;}
label{display:block;font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);margin-bottom:6px;}
button,.btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;font-family:var(--font-body);font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase;border:none;cursor:pointer;transition:background .2s,color .2s;}
.btn-primary{background:var(--accent);color:#fff;}
.btn-primary:hover{background:var(--accent2);}
.btn-ghost{background:transparent;color:var(--muted);border:1.5px solid var(--border2);}
.btn-ghost:hover{border-color:var(--text);color:var(--text);}
.btn-danger{background:#7f1d1d;color:#fff;}
.btn-danger:hover{background:#991b1b;}
.btn-success{background:#15803d;color:#fff;}
.btn-success:hover{background:#166534;}
.btn-sm{padding:6px 12px;font-size:11px;}

/* ── LOGIN ── */
.login-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;}
.login-box{background:var(--surface);border:1.5px solid var(--border2);padding:48px;width:380px;}
.login-logo{font-family:var(--font-display);font-size:28px;letter-spacing:2px;margin-bottom:4px;}
.login-logo span{color:var(--accent);}
.login-sub{color:var(--muted);font-size:13px;margin-bottom:32px;}
.login-box .field{margin-bottom:20px;}
.login-error{background:#7f1d1d;color:#fca5a5;padding:10px 14px;font-size:13px;margin-bottom:20px;}

/* ── LAYOUT ── */
.admin-wrap{display:flex;min-height:100vh;}
.sidebar{width:220px;background:var(--surface);border-right:1.5px solid var(--border);flex-shrink:0;display:flex;flex-direction:column;}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1.5px solid var(--border);}
.sidebar-logo-text{font-family:var(--font-display);font-size:20px;letter-spacing:2px;}
.sidebar-logo-text span{color:var(--accent);}
.sidebar-sub{font-size:10px;color:var(--muted);letter-spacing:1px;text-transform:uppercase;margin-top:2px;}
.sidebar-nav{flex:1;padding:16px 0;}
.nav-item{display:flex;align-items:center;gap:12px;padding:11px 20px;color:var(--muted);font-size:13px;font-weight:500;transition:color .2s,background .2s;cursor:pointer;border-left:3px solid transparent;}
.nav-item:hover{color:var(--text);background:var(--surface2);}
.nav-item.active{color:var(--text);background:var(--surface2);border-left-color:var(--accent);}
.nav-item svg{width:16px;height:16px;flex-shrink:0;}
.sidebar-footer{padding:16px 20px;border-top:1.5px solid var(--border);}
.sidebar-footer a{color:var(--muted);font-size:12px;display:flex;align-items:center;gap:8px;transition:color .2s;}
.sidebar-footer a:hover{color:var(--text);}

/* ── MAIN ── */
.main{flex:1;display:flex;flex-direction:column;overflow:auto;}
.topbar{padding:16px 32px;border-bottom:1.5px solid var(--border);display:flex;align-items:center;justify-content:space-between;background:var(--surface);}
.topbar-title{font-family:var(--font-display);font-size:22px;letter-spacing:2px;}
.topbar-actions{display:flex;gap:10px;}
.content{padding:32px;flex:1;}

/* ── STATS ── */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:32px;}
.stat-card{background:var(--surface);border:1.5px solid var(--border);padding:20px 24px;}
.stat-num{font-family:var(--font-display);font-size:36px;color:var(--accent);line-height:1;}
.stat-label{font-size:11px;color:var(--muted);letter-spacing:1px;text-transform:uppercase;margin-top:4px;}

/* ── TABLE ── */
.table-wrap{background:var(--surface);border:1.5px solid var(--border);overflow:hidden;}
.table-header{padding:16px 20px;border-bottom:1.5px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.table-header-title{font-weight:700;font-size:13px;letter-spacing:0.5px;}
table{width:100%;border-collapse:collapse;}
th{text-align:left;padding:12px 16px;font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);border-bottom:1.5px solid var(--border);background:var(--surface2);}
td{padding:14px 16px;border-bottom:1px solid var(--border);font-size:13px;vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:var(--surface2);}
.badge{display:inline-block;padding:3px 10px;font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;}
.badge-green{background:#14532d;color:#86efac;}
.badge-gray{background:#1f2937;color:#9ca3af;}
.badge-red{background:#450a0a;color:#fca5a5;}
.article-num{font-family:monospace;color:var(--accent);font-size:12px;}
.article-title{font-weight:600;max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.article-cat{font-size:11px;color:var(--muted);}
.actions{display:flex;gap:8px;}

/* ── EDITOR ── */
.editor-grid{display:grid;grid-template-columns:1fr 320px;gap:24px;}
.editor-panel{background:var(--surface);border:1.5px solid var(--border);padding:24px;}
.editor-panel h3{font-family:var(--font-display);font-size:18px;letter-spacing:1px;margin-bottom:20px;padding-bottom:12px;border-bottom:1.5px solid var(--border);}
.field{margin-bottom:20px;}
.field-row{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.field-row-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;}
.img-preview{width:100%;aspect-ratio:16/9;background:var(--surface2);border:1.5px dashed var(--border2);display:flex;align-items:center;justify-content:center;margin-bottom:12px;overflow:hidden;position:relative;}
.img-preview img{width:100%;height:100%;object-fit:cover;}
.img-placeholder{color:var(--muted);font-size:12px;text-align:center;}
.upload-btn-wrap{position:relative;}
.upload-btn-wrap input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;}
.content-editor{min-height:300px;font-size:14px;line-height:1.8;}
.success-msg{background:#14532d;color:#86efac;padding:12px 16px;margin-bottom:20px;font-size:13px;}
.checkbox-wrap{display:flex;align-items:center;gap:10px;}
.checkbox-wrap input{width:auto;}
.checkbox-wrap label{margin:0;text-transform:none;font-size:14px;color:var(--text);font-weight:400;letter-spacing:0;}
.tip{font-size:11px;color:var(--muted);margin-top:6px;}

/* ── UPLOADS GALLERY ── */
.gallery-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;}
.gallery-item{background:var(--surface2);border:1.5px solid var(--border);overflow:hidden;position:relative;aspect-ratio:4/3;cursor:pointer;}
.gallery-item img{width:100%;height:100%;object-fit:cover;transition:opacity .2s;}
.gallery-item:hover img{opacity:0.7;}
.gallery-item-name{position:absolute;bottom:0;left:0;right:0;background:rgba(0,0,0,.8);font-size:10px;padding:4px 8px;color:#aaa;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.upload-zone{border:2px dashed var(--border2);padding:48px;text-align:center;margin-bottom:24px;transition:border-color .2s;cursor:pointer;position:relative;}
.upload-zone:hover{border-color:var(--accent);}
.upload-zone input{position:absolute;inset:0;opacity:0;cursor:pointer;}
.upload-zone-icon{font-size:40px;margin-bottom:12px;}
.upload-zone-text{color:var(--muted);font-size:14px;}
.upload-zone-text strong{color:var(--text);}
</style>
</head>
<body>

<?php if (!isLoggedIn()): ?>
<!-- LOGIN PAGE -->
<div class="login-wrap">
  <div class="login-box">
    <div class="login-logo">Tesla<span>Semi</span>.com</div>
    <div class="login-sub">Admin Panel — Sign In</div>
    <?php if (isset($login_error)): ?>
      <div class="login-error"><?= htmlspecialchars($login_error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="field"><label>Username</label><input type="text" name="username" autofocus required/></div>
      <div class="field"><label>Password</label><input type="password" name="password" required/></div>
      <button type="submit" name="login" class="btn btn-primary" style="width:100%;justify-content:center;">Sign In</button>
    </form>
  </div>
</div>

<?php else: ?>
<!-- ADMIN PANEL -->
<div class="admin-wrap">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="sidebar-logo-text">Tesla<span>Semi</span></div>
      <div class="sidebar-sub">Admin Panel</div>
    </div>
    <nav class="sidebar-nav">
      <a href="admin.php?view=dashboard" class="nav-item <?= $view==='dashboard'?'active':'' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7h18M3 12h18M3 17h18"/></svg>
        Dashboard
      </a>
      <a href="admin.php?view=articles" class="nav-item <?= ($view==='articles'||$view==='edit')?'active':'' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 4H7a2 2 0 01-2-2V6a2 2 0 012-2h7l5 5v11a2 2 0 01-2 2z"/></svg>
        Articles
      </a>
      <a href="admin.php?view=new" class="nav-item <?= $view==='new'?'active':'' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        New Article
      </a>
      <a href="admin.php?view=uploads" class="nav-item <?= $view==='uploads'?'active':'' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        Photo Library
      </a>
      <a href="admin.php?view=ticker" class="nav-item <?= $view==='ticker'?'active':'' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
        Ticker Feed
      </a>
      <a href="index.php" target="_blank" class="nav-item">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
        View Website
      </a>
    </nav>
    <div class="sidebar-footer">
      <a href="admin.php?logout=1">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
        Sign Out
      </a>
    </div>
  </aside>

  <!-- MAIN CONTENT -->
  <div class="main">

    <?php if ($view === 'dashboard'): ?>
    <div class="topbar"><div class="topbar-title">Dashboard</div>
      <div class="topbar-actions"><a href="admin.php?view=new" class="btn btn-primary">+ New Article</a></div>
    </div>
    <div class="content">
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-num"><?= count($articles) ?></div><div class="stat-label">Total Articles</div></div>
        <div class="stat-card"><div class="stat-num"><?= count(array_filter($articles, fn($a)=>$a['published']??false)) ?></div><div class="stat-label">Published</div></div>
        <div class="stat-card"><div class="stat-num"><?= count(array_filter($articles, fn($a)=>!($a['published']??false))) ?></div><div class="stat-label">Drafts</div></div>
        <div class="stat-card"><div class="stat-num"><?= is_dir(UPLOADS_DIR) ? count(glob(UPLOADS_DIR.'*')) : 0 ?></div><div class="stat-label">Photos Uploaded</div></div>
      </div>
      <div class="table-wrap">
        <div class="table-header"><span class="table-header-title">Recent Articles</span><a href="admin.php?view=articles" class="btn btn-ghost btn-sm">View All</a></div>
        <table>
          <thead><tr><th>#</th><th>Title</th><th>Category</th><th>Author</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
          <?php foreach (array_slice($articles, 0, 8) as $a): ?>
          <tr>
            <td><span class="article-num"><?= htmlspecialchars($a['num']??'') ?></span></td>
            <td><div class="article-title"><?= htmlspecialchars($a['title']) ?></div></td>
            <td><span class="article-cat"><?= htmlspecialchars($a['category']??'') ?></span></td>
            <td><?= htmlspecialchars($a['author']??'') ?></td>
            <td><?= htmlspecialchars($a['date']??'') ?></td>
            <td><span class="badge <?= ($a['published']??false)?'badge-green':'badge-gray' ?>"><?= ($a['published']??false)?'Live':'Draft' ?></span></td>
            <td><div class="actions">
              <a href="admin.php?view=edit&edit=<?= $a['id'] ?>" class="btn btn-ghost btn-sm">Edit</a>
              <a href="admin.php?delete=<?= $a['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this article?')">Del</a>
            </div></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php elseif ($view === 'articles'): ?>
    <div class="topbar"><div class="topbar-title">All Articles</div>
      <div class="topbar-actions"><a href="admin.php?view=new" class="btn btn-primary">+ New Article</a></div>
    </div>
    <div class="content">
      <div class="table-wrap">
        <table>
          <thead><tr><th>#</th><th>Title</th><th>Category</th><th>Author</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
          <?php foreach ($articles as $a): ?>
          <tr>
            <td><span class="article-num"><?= htmlspecialchars($a['num']??'') ?></span></td>
            <td><div class="article-title"><?= htmlspecialchars($a['title']) ?></div></td>
            <td><span class="article-cat"><?= htmlspecialchars($a['category']??'') ?></span></td>
            <td><?= htmlspecialchars($a['author']??'') ?></td>
            <td><?= htmlspecialchars($a['date']??'') ?></td>
            <td><span class="badge <?= ($a['published']??false)?'badge-green':'badge-gray' ?>"><?= ($a['published']??false)?'Live':'Draft' ?></span></td>
            <td><div class="actions">
              <a href="admin.php?toggle=<?= $a['id'] ?>" class="btn btn-success btn-sm"><?= ($a['published']??false)?'Unpublish':'Publish' ?></a>
              <a href="admin.php?view=edit&edit=<?= $a['id'] ?>" class="btn btn-ghost btn-sm">Edit</a>
              <a href="admin.php?delete=<?= $a['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this article?')">Del</a>
            </div></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($articles)): ?><tr><td colspan="7" style="text-align:center;color:var(--muted);padding:40px;">No articles yet. <a href="admin.php?view=new" style="color:var(--accent);">Create your first one.</a></td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php elseif ($view === 'new' || $view === 'edit'): ?>
    <div class="topbar">
      <div class="topbar-title"><?= $editing ? 'Edit Article' : 'New Article' ?></div>
      <div class="topbar-actions"><a href="admin.php?view=articles" class="btn btn-ghost">← Back</a></div>
    </div>
    <div class="content">
      <?php if (isset($success)): ?><div class="success-msg">✓ <?= $success ?></div><?php endif; ?>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="article_id" value="<?= $editing['id'] ?? '' ?>"/>
        <div class="editor-grid">
          <!-- LEFT: Main Editor -->
          <div>
            <div class="editor-panel">
              <h3>Article Content</h3>
              <div class="field">
                <label>Headline / Title *</label>
                <input type="text" name="title" value="<?= htmlspecialchars($editing['title']??'') ?>" required placeholder="Write a punchy headline..."/>
              </div>
              <div class="field">
                <label>Excerpt / Summary</label>
                <textarea name="excerpt" rows="3" placeholder="A short 1-2 sentence preview shown on the homepage..."><?= htmlspecialchars($editing['excerpt']??'') ?></textarea>
              </div>
              <div class="field">
                <label>Full Article Body</label>
                <textarea name="content" class="content-editor" placeholder="Write the full article here. HTML is supported for formatting."><?= htmlspecialchars($editing['content']??'') ?></textarea>
                <div class="tip">You can use basic HTML: &lt;p&gt;, &lt;strong&gt;, &lt;h2&gt;, &lt;ul&gt;, &lt;li&gt;, &lt;br&gt;</div>
              </div>
            </div>
          </div>
          <!-- RIGHT: Meta + Image -->
          <div style="display:flex;flex-direction:column;gap:16px;">
            <div class="editor-panel">
              <h3>Publish</h3>
              <div class="field">
                <div class="checkbox-wrap">
                  <input type="checkbox" name="published" id="published" <?= ($editing['published']??false)?'checked':'' ?>/>
                  <label for="published">Publish (make live on site)</label>
                </div>
              </div>
              <button type="submit" name="save_article" class="btn btn-primary" style="width:100%;justify-content:center;">Save Article</button>
            </div>
            <div class="editor-panel">
              <h3>Article Details</h3>
              <div class="field-row">
                <div class="field"><label>Article # (e.g. 021)</label><input type="text" name="num" value="<?= htmlspecialchars($editing['num']??'') ?>" placeholder="021"/></div>
                <div class="field"><label>Category</label>
                  <select name="category">
                    <?php foreach(['News','Charging','Production','Pilot Programs','Europe','Specs','Infrastructure','Efficiency'] as $cat): ?>
                    <option <?= ($editing['category']??'')===$cat?'selected':'' ?>><?= $cat ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
              <div class="field-row">
                <div class="field"><label>Author</label><input type="text" name="author" value="<?= htmlspecialchars($editing['author']??'') ?>" placeholder="Simon Alvarez"/></div>
                <div class="field"><label>Read Time</label><input type="text" name="read_time" value="<?= htmlspecialchars($editing['read_time']??'2 min read') ?>" placeholder="2 min read"/></div>
              </div>
              <div class="field"><label>Date</label><input type="date" name="date" value="<?= htmlspecialchars($editing['date']??date('Y-m-d')) ?>"/></div>
            </div>
            <div class="editor-panel">
              <h3>Featured Image</h3>
              <div class="img-preview" id="imgPreview">
                <?php if (!empty($editing['image'])): ?>
                  <img src="<?= htmlspecialchars($editing['image']) ?>" id="previewImg"/>
                <?php else: ?>
                  <div class="img-placeholder">
                    <div style="font-size:32px;margin-bottom:8px;">🖼</div>
                    <div>No image selected</div>
                  </div>
                <?php endif; ?>
              </div>
              <input type="hidden" name="image_url" id="imageUrl" value="<?= htmlspecialchars($editing['image']??'') ?>"/>
              <div class="field">
                <label>Upload New Image</label>
                <div class="upload-btn-wrap">
                  <button type="button" class="btn btn-ghost" style="width:100%;justify-content:center;">📁 Choose Image File</button>
                  <input type="file" id="imageUpload" accept="image/*" onchange="uploadImage(this)"/>
                </div>
                <div class="tip" id="uploadStatus">JPG, PNG, WebP supported</div>
              </div>
              <div class="field">
                <label>— or paste image URL —</label>
                <input type="text" id="imageUrlInput" value="<?= htmlspecialchars($editing['image']??'') ?>" placeholder="https://..." oninput="setImageFromUrl(this.value)"/>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>

    <?php elseif ($view === 'uploads'): ?>
    <div class="topbar"><div class="topbar-title">Photo Library</div></div>
    <div class="content">
      <div class="editor-panel" style="margin-bottom:24px;">
        <h3>Upload Photos</h3>
        <div class="upload-zone" id="uploadZone">
          <input type="file" id="bulkUpload" accept="image/*" multiple onchange="bulkUpload(this)"/>
          <div class="upload-zone-icon">📸</div>
          <div class="upload-zone-text"><strong>Click to upload</strong> or drag & drop photos here</div>
          <div style="font-size:12px;color:var(--muted);margin-top:8px;">JPG, PNG, WebP, GIF</div>
        </div>
        <div id="uploadProgress"></div>
      </div>
      <div class="table-wrap" style="padding:20px;">
        <div class="table-header" style="margin-bottom:16px;"><span class="table-header-title">Uploaded Photos</span></div>
        <div class="gallery-grid" id="galleryGrid">
          <?php
          $imgs = is_dir(UPLOADS_DIR) ? glob(UPLOADS_DIR.'*.{jpg,jpeg,png,webp,gif}', GLOB_BRACE) : [];
          foreach ($imgs as $img): ?>
          <div class="gallery-item" onclick="copyUrl('<?= $img ?>')">
            <img src="<?= htmlspecialchars($img) ?>" alt=""/>
            <div class="gallery-item-name"><?= basename($img) ?></div>
          </div>
          <?php endforeach; ?>
          <?php if (empty($imgs)): ?>
          <div style="color:var(--muted);font-size:13px;grid-column:1/-1;padding:20px 0;">No photos uploaded yet.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php elseif ($view === 'ticker'): ?>
    <div class="topbar"><div class="topbar-title">Ticker Feed</div></div>
    <div class="content">
      <?php if (isset($ticker_success)): ?>
        <div class="success-msg"><?= htmlspecialchars($ticker_success) ?></div>
      <?php endif; ?>
      <div class="editor-panel" style="max-width:720px;">
        <h3>Scrolling News Ticker</h3>
        <form method="POST">
          <div class="field">
            <label>Ticker Items — one per line</label>
            <textarea name="ticker_items" rows="12" placeholder="Tesla Semi begins high-volume production in 2026&#10;First public Megacharger opens in Los Angeles — 750 kW charging&#10;Semi Long Range: 500 miles at 82,000 lbs GCW"><?= htmlspecialchars(implode("\n", $ticker['items'] ?? [])) ?></textarea>
            <div class="tip">Each line = one item in the scrolling ticker. Keep them short and punchy. Changes go live instantly after saving.</div>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
            <button type="submit" name="save_ticker" class="btn btn-primary">Save Ticker</button>
            <a href="index.php" target="_blank" class="btn btn-ghost btn-sm">Preview Live Site ↗</a>
          </div>
        </form>
      </div>
      <div class="editor-panel" style="max-width:720px;margin-top:24px;">
        <h3>Live Preview</h3>
        <div style="background:#c8102e;overflow:hidden;height:34px;display:flex;align-items:center;border:1.5px solid #333;">
          <div id="tickerPreview" style="display:flex;white-space:nowrap;animation:tickerPrev 20s linear infinite;padding-left:24px;"></div>
        </div>
        <div class="tip" style="margin-top:8px;">Updates as you type above.</div>
      </div>
    </div>
    <style>
      @keyframes tickerPrev{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
    </style>
    <script>
      function updatePreview() {
        const lines = document.querySelector('textarea[name=ticker_items]').value.split('\n').map(s=>s.trim()).filter(Boolean);
        const doubled = [...lines, ...lines];
        document.getElementById('tickerPreview').innerHTML = doubled.map(t=>`<span style="font-size:11px;font-weight:600;color:#fff;padding:0 40px;letter-spacing:.5px;"><span style="margin-right:12px;font-size:8px;">●</span>${t}</span>`).join('');
      }
      document.querySelector('textarea[name=ticker_items]').addEventListener('input', updatePreview);
      updatePreview();
    </script>

    <?php endif; ?>

  </div><!-- /main -->
</div><!-- /admin-wrap -->

<script>
// Image upload for article editor
function uploadImage(input) {
  const file = input.files[0];
  if (!file) return;
  const status = document.getElementById('uploadStatus');
  status.textContent = 'Uploading...';
  const fd = new FormData();
  fd.append('image', file);
  fetch('admin.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        setImageFromUrl(data.url);
        document.getElementById('imageUrlInput').value = data.url;
        status.textContent = '✓ Uploaded: ' + data.url;
      }
    })
    .catch(() => { status.textContent = 'Upload failed.'; });
}

function setImageFromUrl(url) {
  document.getElementById('imageUrl').value = url;
  const preview = document.getElementById('imgPreview');
  if (url) {
    preview.innerHTML = '<img src="'+url+'" id="previewImg" style="width:100%;height:100%;object-fit:cover;"/>';
  }
}

// Bulk upload for photo library
function bulkUpload(input) {
  const files = Array.from(input.files);
  const progress = document.getElementById('uploadProgress');
  let done = 0;
  progress.innerHTML = '<p style="color:var(--muted);margin-top:12px;">Uploading '+files.length+' file(s)...</p>';
  files.forEach(file => {
    const fd = new FormData();
    fd.append('image', file);
    fetch('admin.php', { method: 'POST', body: fd })
      .then(r => r.json())
      .then(data => {
        done++;
        if (data.success) {
          const grid = document.getElementById('galleryGrid');
          const div = document.createElement('div');
          div.className = 'gallery-item';
          div.onclick = () => copyUrl(data.url);
          div.innerHTML = '<img src="'+data.url+'"/><div class="gallery-item-name">'+data.url.split('/').pop()+'</div>';
          grid.prepend(div);
        }
        if (done === files.length) progress.innerHTML = '<p style="color:var(--green);margin-top:12px;">✓ All '+done+' files uploaded!</p>';
      });
  });
}

function copyUrl(url) {
  navigator.clipboard.writeText(url).then(() => {
    alert('URL copied to clipboard:\n' + url);
  });
}
</script>
<?php endif; ?>
</body>
</html>
